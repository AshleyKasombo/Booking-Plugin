<?PHP
defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir.'/formslib.php');

/**
 * Base class for slot-related forms
 */
abstract class bookking_slotform_base extends moodleform {

    protected $bookking;
    protected $cm;
    protected $context;
    protected $usergroups;
    protected $has_duration = false;

    public function __construct($action, bookking_instance $bookking, $cm, $usergroups, $customdata=null) {
        $this->bookking = $bookking;
        $this->cm = $cm;
        $this->context = context_module::instance($cm->id);
        $this->usergroups = $usergroups;
        parent::__construct($action, $customdata);
    }

    protected function add_base_fields() {

        global $CFG, $USER;

        $mform = $this->_form;

        // exclusivity
        $exclgroup = array();

        $exclgroup[] = $mform->createElement('text', 'exclusivity', '', array('size' => '10'));
        $mform->setType('exclusivity', PARAM_INTEGER);
        $mform->setDefault('exclusivity', 1);

        $exclgroup[] = $mform->createElement('advcheckbox', 'exclusivityenable', '', get_string('enable'));
        $mform->setDefault('exclusivityenable', 1);
        $mform->disabledIf('exclusivity', 'exclusivityenable', 'eq', 0);

        $mform->addGroup($exclgroup, 'exclusivitygroup', get_string('maxstudentsperslot', 'bookking'), ' ', false);
        $mform->addHelpButton('exclusivitygroup', 'exclusivity', 'bookking');

        // location of the appointment
        $mform->addElement('text', 'appointmentlocation', get_string('location', 'bookking'), array('size' => '30'));
        $mform->setType('appointmentlocation', PARAM_TEXT);
        $mform->addRule('appointmentlocation', get_string('error'), 'maxlength', 255);
        $mform->setDefault('appointmentlocation', $this->bookking->get_last_location($USER));
        $mform->addHelpButton('appointmentlocation', 'location', 'bookking');

        // Choose the teacher (if allowed)
        if (has_capability('mod/bookking:canscheduletootherteachers', $this->context)) {
            $teachername = s($this->bookking->get_teacher_name());
            $teachers = bookking_get_attendants($this->cm->id);
            $teachersmenu = array();
            if ($teachers) {
                foreach ($teachers as $teacher) {
                    $teachersmenu[$teacher->id] = fullname($teacher);
                }
                $mform->addElement('select', 'teacherid', $teachername, $teachersmenu);
                $mform->addRule('teacherid', get_string('noteacherforslot', 'bookking'), 'required');
                $mform->setDefault('teacherid', $USER->id);
            } else {
                $mform->addElement('static', 'teacherid', $teachername, get_string('noteachershere', 'bookking', $teachername));
            }
            $mform->addHelpButton('teacherid', 'bookwithteacher', 'bookking');
        } else {
            $mform->addElement('hidden', 'teacherid');
            $mform->setDefault('teacherid', $USER->id);
            $mform->setType('teacherid', PARAM_INT);
        }

    }

    protected function add_minutes_field($name, $label, $defaultval, $minuteslabel = 'minutes') {
        $mform = $this->_form;
        $group = array();
        $group[] =& $mform->createElement('text', $name, '', array('size' => 5));
        $group[] =& $mform->createElement('static', $name.'mintext', '', get_string($minuteslabel, 'bookking'));
        $mform->addGroup($group, $name.'group', get_string($label, 'bookking'), array(' '), false);
        $mform->setType($name, PARAM_INT);
        $mform->setDefault($name, $defaultval);
    }

    protected function add_duration_field($minuteslabel = 'minutes') {
        $this->add_minutes_field('duration', 'duration', $this->bookking->defaultslotduration, $minuteslabel);
        $this->has_duration = true;
    }


    public function validation($data, $files) {
        $errors = parent::validation($data, $files);

        // Check duration for valid range
        if ($this->has_duration) {
            $limits = array('min' => 1, 'max' => 24*60);
            if ($data['duration'] < $limits['min'] || $data['duration'] > $limits['max']) {
                $errors['durationgroup'] = get_string('durationrange', 'bookking', $limits);
            }
        }

        return $errors;
    }
}

class bookking_editslot_form extends bookking_slotform_base {

    protected $slotid;

    protected function definition() {

        global $DB, $output;

        $mform = $this->_form;
        $this->slotid = 0;
        if (isset($this->_customdata['slotid'])) {
            $this->slotid = $this->_customdata['slotid'];
        }

        // Start date/time of the slot
        $mform->addElement('date_time_selector', 'starttime', get_string('date', 'bookking'));
        $mform->setDefault('starttime', time());
        $mform->addHelpButton('starttime', 'choosingslotstart', 'bookking');

        // Duration of the slot
        $this->add_duration_field();

        // Ignore conflict checkbox
        $mform->addElement('checkbox', 'ignoreconflicts', get_string('ignoreconflicts', 'bookking'));
        $mform->setDefault('ignoreconflicts', false);
        $mform->addHelpButton('ignoreconflicts', 'ignoreconflicts', 'bookking');

        // Common fields
        $this->add_base_fields();

        // Display slot from date
        $mform->addElement('date_selector', 'hideuntil', get_string('displayfrom', 'bookking'));
        $mform->setDefault('hideuntil', time());

        // Send e-mail reminder
        $mform->addElement('date_selector', 'emaildate', get_string('emailreminderondate', 'bookking'), array('optional'  => true));
        $mform->setDefault('remindersel', -1);

        // Slot comments
        $mform->addElement('editor', 'notes', get_string('comments', 'bookking'), array('rows' => 3, 'columns' => 60), array('collapsed' => true));
        $mform->setType('notes', PARAM_RAW); // must be PARAM_RAW for rich text editor content

        // Appointments

        $repeatarray = array();
        $grouparray = array();
        $repeatarray[] = $mform->createElement('header', 'appointhead', get_string('appointmentno', 'bookking', '{no}'));

        // Choose student
        $students = $this->bookking->get_possible_attendees($this->usergroups);
        $studentsmenu = array('0' => get_string('choosedots'));
        if ($students) {
            foreach ($students as $astudent) {
                $studentsmenu[$astudent->id] = fullname($astudent);
            }
        }
        $grouparray[] = $mform->createElement('select', 'studentid', '', $studentsmenu);

        // Seen tickbox
        $grouparray[] = $mform->createElement('static', 'attendedlabel', '', get_string('seen', 'bookking'));
        $grouparray[] = $mform->createElement('checkbox', 'attended');

        // Grade
        if ($this->bookking->scale != 0) {
            $gradechoices = $output->grading_choices($this->bookking);
            $grouparray[] = $mform->createElement('static', 'attendedlabel', '', get_string('grade', 'bookking'));
            $grouparray[] = $mform->createElement('select', 'grade', '', $gradechoices);
        }

        $repeatarray[] = $mform->createElement('group', 'studgroup', get_string('student', 'bookking'), $grouparray, null, false);

        // Appointment notes
        $repeatarray[] = $mform->createElement('editor', 'appointmentnote', get_string('appointmentnotes', 'bookking'),
                          array('rows' => 3, 'columns' => 60), array('collapsed' => true));

        if (isset($this->_customdata['repeats'])) {
            $repeatno = $this->_customdata['repeats'];
        } else if ($this->slotid) {
            $repeatno = $DB->count_records('bookking_appointment', array('slotid' => $this->slotid));
            $repeatno += 1;
        } else {
            $repeatno = 1;
        }

        $repeateloptions = array();
        $nostudcheck = array('studentid', 'eq', 0);
        $repeateloptions['attended']['disabledif'] = $nostudcheck;
        $repeateloptions['appointmentnote']['disabledif'] = $nostudcheck;
        $repeateloptions['grade']['disabledif'] = $nostudcheck;
        $repeateloptions['appointhead']['expanded'] = true;

        $this->repeat_elements($repeatarray, $repeatno, $repeateloptions,
                        'appointment_repeats', 'appointment_add', 1, get_string('addappointment', 'bookking'));

        $this->add_action_buttons();

    }

    public function validation($data, $files) {
        $errors = parent::validation($data, $files);

        // Check number of appointments vs exclusivity
        $numappointments = 0;
        for ($i = 0; $i < $data['appointment_repeats']; $i++) {
            if ($data['studentid'][$i] > 0) {
                $numappointments++;
            }
        }
        if ($data['exclusivityenable'] && $data['exclusivity'] <= 0) {
            $errors['exclusivitygroup'] = get_string('exclusivitypositive', 'bookking');
        } else if ($data['exclusivityenable'] && $numappointments > $data['exclusivity']) {
            $errors['exclusivitygroup'] = get_string('exclusivityoverload', 'bookking', $numappointments);
        }

        // Avoid empty slots starting in the past
        if ($numappointments == 0 && $data['starttime'] < time()) {
            $errors['starttime'] = get_string('startpast', 'bookking');
        }

        // Check whether students have been selected several times
        for ($i = 0; $i < $data['appointment_repeats']; $i++) {
            for ($j = 0; $j < $i; $j++) {
                if ($data['studentid'][$i] > 0 && $data['studentid'][$i] == $data['studentid'][$j]) {
                    $errors['studgroup['.$i.']'] = get_string('studentmultiselect', 'bookking');
                    $errors['studgroup['.$j.']'] = get_string('studentmultiselect', 'bookking');
                }
            }
        }

        if (!isset($data['ignoreconflicts'])) {
            // Avoid overlapping slots, by asking the user if they'd like to overwrite the existing ones...
            // for other bookking, we check independently of exclusivity. Any slot here conflicts
            // for this bookking, we check against exclusivity. Any complete slot here conflicts
            $conflicts_remote = bookking_get_conflicts($this->bookking->id,
                            $data['starttime'], $data['starttime'] + $data['duration'] * 60, $data['teacherid'], 0, bookking_OTHERS, false);
            $conflicts_local = bookking_get_conflicts($this->bookking->id,
                            $data['starttime'], $data['starttime'] + $data['duration'] * 60, $data['teacherid'], 0, bookking_SELF, true);
            if (!$conflicts_remote) {
                $conflicts_remote = array();
            }
            if (!$conflicts_local) {
                $conflicts_local = array();
            }
            $conflicts = $conflicts_remote + $conflicts_local;

            // remove itself from conflicts when updating
            if (array_key_exists($this->slotid, $conflicts)) {
                unset($conflicts[$this->slotid]);
            }

            if (count($conflicts)) {
                $msg = get_string('slotwarning', 'bookking');

                foreach ($conflicts as $conflict) {
                    $students = bookking_get_appointed($conflict->id);

                    $slotmsg = userdate($conflict->starttime);
                    $slotmsg .= ' [';
                    $slotmsg .= $conflict->duration.' '.get_string('minutes');
                    $slotmsg .= ']';

                    if ($students) {
                        $slotmsg .= ' (';
                        $appointed = array();
                        foreach ($students as $astudent) {
                            $appointed[] = fullname($astudent);
                        }
                        if (count ($appointed)) {
                            $slotmsg .= implode(', ', $appointed);
                        }
                        unset ($appointed);
                        $slotmsg .= ')';
                        $slotmsg = html_writer::tag('b', $slotmsg);
                    }
                    $msg .= html_writer::div($slotmsg);
                }

                $errors['starttime'] = $msg;
            }
        }
        return $errors;
    }
}


class bookking_addsession_form extends bookking_slotform_base {

    protected function definition() {

        global $DB;

        $mform = $this->_form;

        // Start and end of range
        $mform->addElement('date_selector', 'rangestart', get_string('date', 'bookking'));
        $mform->setDefault('rangestart', time());

        $mform->addElement('date_selector', 'rangeend', get_string('enddate', 'bookking'),
                            array('optional'  => true) );

        // Weekdays selection
        $weekdays = array('monday', 'tuesday', 'wednesday', 'thursday', 'friday');
        foreach ($weekdays as $day) {
            $label = ($day == 'monday') ? get_string('addondays', 'bookking') : '';
            $mform->addElement('advcheckbox', $day, $label, get_string($day, 'bookking'));
            $mform->setDefault($day, true);
        }
        $mform->addElement('advcheckbox', 'saturday', '', get_string('saturday', 'bookking'));
        $mform->addElement('advcheckbox', 'sunday', '', get_string('sunday', 'bookking'));

        // Start and end time
        $hours = array();
        $minutes = array();
        for ($i=0; $i<=23; $i++) {
            $hours[$i] = sprintf("%02d", $i);
        }
        for ($i=0; $i<60; $i+=5) {
            $minutes[$i] = sprintf("%02d", $i);
        }
        $starttimegroup = array();
        $starttimegroup[] = $mform->createElement('select', 'starthour', get_string('hour', 'form'), $hours);
        $starttimegroup[] = $mform->createElement('select', 'startminute', get_string('minute', 'form'), $minutes);
        $mform->addGroup ($starttimegroup, 'starttime', get_string('starttime', 'bookking'), null, false);
        $endtimegroup = array();
        $endtimegroup[] = $mform->createElement('select', 'endhour', get_string('hour', 'form'), $hours);
        $endtimegroup[] = $mform->createElement('select', 'endminute', get_string('minute', 'form'), $minutes);
        $mform->addGroup ($endtimegroup, 'endtime', get_string('endtime', 'bookking'), null, false);

        // Divide into slots?
        $mform->addElement('selectyesno', 'divide', get_string('divide', 'bookking'));
        $mform->setDefault('divide', 1);

        // Duration of the slot
        $this->add_duration_field('minutesperslot');

        // Break between slots
        $this->add_minutes_field('break', 'break', 0, 'minutes');

        // Force when overlap?
        $mform->addElement('selectyesno', 'forcewhenoverlap', get_string('forcewhenoverlap', 'bookking'));
        $mform->addHelpButton('forcewhenoverlap', 'forcewhenoverlap', 'bookking');

        // Common fields
        $this->add_base_fields();

        // Display slot from date - relative
        $hideuntilsel = array();
        $hideuntilsel[0] =  get_string('now', 'bookking');
        $hideuntilsel[DAYSECS] = get_string('onedaybefore', 'bookking');
        for ($i = 2; $i < 7; $i++) {
            $hideuntilsel[DAYSECS*$i] = get_string('xdaysbefore', 'bookking', $i);
        }
        $hideuntilsel[WEEKSECS] = get_string('oneweekbefore', 'bookking');
        for ($i = 2; $i < 7; $i++) {
            $hideuntilsel[WEEKSECS*$i] = get_string('xweeksbefore', 'bookking', $i);
        }
        $mform->addElement('select', 'hideuntilrel', get_string('displayfrom', 'bookking'), $hideuntilsel);
        $mform->setDefault('hideuntilsel', 0);

        // E-mail reminder from
        $remindersel = array();
        $remindersel[-1] = get_string('never', 'bookking');
        $remindersel[0] = get_string('onthemorningofappointment', 'bookking');
        $remindersel[DAYSECS] = get_string('onedaybefore', 'bookking');
        for ($i = 2; $i < 7; $i++) {
            $remindersel[DAYSECS * $i] = get_string('xdaysbefore', 'bookking', $i);
        }
        $remindersel[WEEKSECS] = get_string('oneweekbefore', 'bookking');
        for ($i = 2; $i < 7; $i++) {
            $remindersel[WEEKSECS*$i] = get_string('xweeksbefore', 'bookking', $i);
        }

        $mform->addElement('select', 'emaildaterel', get_string('emailreminder', 'bookking'), $remindersel);
        $mform->setDefault('remindersel', -1);

        $this->add_action_buttons();

    }

    public function validation($data, $files) {
        $errors = parent::validation($data, $files);

        // Range is negative
        $fordays = 0;
        if ($data['rangeend'] > 0) {
            $fordays = ($data['rangeend'] - $data['rangestart']) / DAYSECS;
            if ($fordays < 0) {
                $errors['rangeend'] = get_string('negativerange', 'bookking');
            }
        }

        // Time range is negative
        $starttime = $data['starthour']*60+$data['startminute'];
        $endtime = $data['endhour']*60+$data['endminute'];
        if ($starttime > $endtime)  {
            $errors['endtime'] = get_string('negativerange', 'bookking');
        }

        // First slot is in the past
        if ($data['rangestart'] < time() - DAYSECS) {
            $errors['rangestart'] = get_string('startpast', 'bookking');
        }

        // Break must be nonnegative
        if ($data['break'] < 0) {
            $errors['breakgroup'] = get_string('breaknotnegative', 'bookking');
        }

        // TODO conflict checks

        /*

        /// make a base slot for generating
        $slot = new stdClass();
        $slot->appointmentlocation = $data->appointmentlocation;
        $slot->exclusivity = $data->exclusivity;
        $slot->duration = $data->duration;
        $slot->bookkingid = $bookking->id;
        $slot->timemodified = time();
        $slot->teacherid = $data->teacherid;

        /// check if overlaps. Check also if some slots are in allowed day range
        $startfrom = $data->rangestart;
        $noslotsallowed = true;
        for ($d = 0; $d <= $fordays; $d ++){
        $starttime = $startfrom + ($d * DAYSECS);
        $eventdate = usergetdate($starttime);
        $dayofweek = $eventdate['wday'];
        if ((($dayofweek == 1) && ($data->monday == 1)) ||
                        (($dayofweek == 2) && ($data->tuesday == 1)) ||
                        (($dayofweek == 3) && ($data->wednesday == 1)) ||
                        (($dayofweek == 4) && ($data->thursday == 1)) ||
                        (($dayofweek == 5) && ($data->friday == 1)) ||
                        (($dayofweek == 6) && ($data->saturday == 1)) ||
                        (($dayofweek == 0) && ($data->sunday == 1))){
                        $noslotsallowed = false;
                        $data->starttime = make_timestamp($eventdate['year'], $eventdate['mon'], $eventdate['mday'], $data->starthour, $data->startminute);
                        $conflicts = bookking_get_conflicts($bookking->id, $data->starttime, $data->starttime + $data->duration * 60, $data->teacherid, 0, bookking_ALL, false);
                        if (!$data->forcewhenoverlap){
                        if ($conflicts){
                        unset($erroritem);
                        $erroritem->message = get_string('overlappings', 'bookking');
                        $erroritem->on = 'range';
                        $errors[] = $erroritem;
                        }
                        }
                        }
                        }

                        /// Finally check if some slots are allowed (an error is thrown to ask care to this situation)
                        if ($noslotsallowed){
                        unset($erroritem);
                        $erroritem->message = get_string('allslotsincloseddays', 'bookking');
                        $erroritem->on = 'days';
                        $errors[] = $erroritem;
                        }
         */

        return $errors;
    }
}
