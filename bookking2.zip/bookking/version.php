<?PHP

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'mod_bookking'; // Full name of the plugin (used for diagnostics)
$plugin->version   = 2015102904;      // The current module version (Date: YYYYMMDDXX)
$plugin->release   = '2.9.2';         // Human-friendly version name
$plugin->requires  = 2015042800;      // Requires Moodle 2.9
$plugin->maturity  = MATURITY_STABLE; // Stable release

$plugin->cron     = 60;               // Period for cron to check this module (secs)
