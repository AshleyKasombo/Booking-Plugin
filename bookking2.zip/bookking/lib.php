<?PHP

defined('MOODLE_INTERNAL') || die();

// Library of functions and constants for module bookking.

require_once($CFG->dirroot.'/mod/bookking/locallib.php');
require_once($CFG->dirroot.'/mod/bookking/mailtemplatelib.php');

define('bookking_TIMEUNKNOWN', 0);  // This is used for appointments for which no time is entered.
define('bookking_SELF', 0); // Used for setting conflict search scope.
define('bookking_OTHERS', 1); // Used for setting conflict search scope.
define('bookking_ALL', 2); // Used for setting conflict search scope.

define ('bookking_MEAN_GRADE', 0); // Used for grading strategy.
define ('bookking_MAX_GRADE', 1);  // Used for grading strategy.

/**
 * Given an object containing all the necessary data,
 * will create a new instance and return the id number
 * of the new instance.
 * @param object $bookking the current instance
 * @return int the new instance id
 * @uses $DB
 */
function bookking_add_instance($bookking) {
    global $DB;

    $bookking->timemodified = time();
    $bookking->scale = isset($bookking->grade) ? $bookking->grade : 0;

    $id = $DB->insert_record('bookking', $bookking);
    $bookking->id = $id;

    bookking_grade_item_update($bookking);

    return $id;
}

/**
 * Given an object containing all the necessary data,
 * (defined by the form in mod.html) this function
 * will update an existing instance with new data.
 * @param object $bookking the current instance
 * @return object the updated instance
 * @uses $DB
 */
function bookking_update_instance($bookking) {
    global $DB;

    $bookking->timemodified = time();
    $bookking->id = $bookking->instance;

    $bookking->scale = $bookking->grade;

    $DB->update_record('bookking', $bookking);

    // Update grade item and grades.
    bookking_update_grades($bookking);

    return true;
}


/**
 * Given an ID of an instance of this module,
 * this function will permanently delete the instance
 * and any data that depends on it.
 * @param int $id the instance to be deleted
 * @return boolean true if success, false otherwise
 * @uses $DB
 */
function bookking_delete_instance($id) {
    global $DB;

    if (! $DB->record_exists('bookking', array('id' => $id))) {
        return false;
    }

    $bookking = bookking_instance::load_by_id($id);
    $bookking->delete();

    // Clean up any possibly remaining event records.
    $params = array('modulename' => 'bookking', 'instance' => $id);
    $DB->delete_records('event', $params);

    return true;
}

/**
 * Return a small object with summary information about what a
 * user has done with a given particular instance of this module
 * Used for user activity reports.
 * $return->time = the time they did it
 * $return->info = a short text description
 * @param object $course the course instance
 * @param object $user the concerned user instance
 * @param object $mod the current course module instance
 * @param object $bookking the activity module behind the course module instance
 * @return object an information object as defined above
 */
function bookking_user_outline($course, $user, $mod, $bookking) {
    $return = NULL;
    return $return;
}

/**
 * Prints a detailed representation of what a  user has done with
 * a given particular instance of this module, for user activity reports.
 * @param object $course the course instance
 * @param object $user the concerned user instance
 * @param object $mod the current course module instance
 * @param object $bookking the activity module behind the course module instance
 * @param boolean true if the user completed activity, false otherwise
 */
function bookking_user_complete($course, $user, $mod, $bookking) {

    return true;
}

/**
 * Given a course and a time, this module should find recent activity
 * that has occurred in bookking activities and print it out.
 * Return true if there was output, or false is there was none.
 * @param object $course the course instance
 * @param boolean $isteacher true tells a teacher uses the function
 * @param int $timestart a time start timestamp
 * @return boolean true if anything was printed, otherwise false
 */
function bookking_print_recent_activity($course, $isteacher, $timestart) {

    return false;
}

/**
 * Function to be run periodically according to the moodle
 * This function searches for things that need to be done, such
 * as sending out mail, toggling flags etc ...
 * @return boolean always true
 * @uses $CFG
 * @uses $DB
 */
function bookking_cron () {
    global $CFG, $DB;

    $date = make_timestamp(date('Y'), date('m'), date('d'), date('H'), date('i'));

    // for every appointment in all bookkings
    $select = 'emaildate > 0 AND emaildate <= ? AND starttime > ?';
    $slots = $DB->get_records_select('bookking_slots', $select, array($date, $date), 'starttime');

    foreach ($slots as $slot) {
        // get teacher
        $teacher = $DB->get_record('user', array('id' => $slot->teacherid));

        // get bookking, slot and course
        $bookking = bookking_instance::load_by_id($slot->bookkingid);
        $slotm = $bookking->get_slot($slot->id);
        $course = $DB->get_record('course', array('id' => $bookking->course));

        // get appointed student list
        $appointments = $DB->get_records('bookking_appointment', array('slotid'=>$slot->id), '', 'id, studentid');

        //if no email previously sent and one is required
        foreach ($appointments as $appointment) {
            $student = $DB->get_record('user', array('id'=>$appointment->studentid));
            cron_setup_user($student, $course);
            $vars = bookking_get_mail_variables ($bookking, $slotm, $teacher, $student, $course, $student);
            bookking_send_email_from_template ($student, $teacher, $course, 'remindtitle', 'reminder', $vars, 'bookking');
        }
        // mark as sent
        $slot->emaildate = -1;
        $DB->update_record('bookking_slots', $slot);
    }

    cron_setup_user();

    return true;
}



/**
 * Returns the users with data in one bookking
 * (users with records in journal_entries, students and teachers)
 * @param int $bookkingid the id of the activity module
 * @uses $CFG
 * @uses $DB
 */
function bookking_get_participants($bookkingid) {
    global $CFG, $DB;

    //Get students using slots they have
    $sql = '
        SELECT DISTINCT
        u.*
        FROM
        {user} u,
        {bookking_slots} s,
        {bookking_appointment} a
        WHERE
        s.bookkingid = ? AND
        s.id = a.slotid AND
        u.id = a.studentid
        ';
    $students = $DB->get_records_sql($sql, array($bookkingid));

    //Get teachers using slots they have
    $sql = '
        SELECT DISTINCT
        u.*
        FROM
        {user} u,
        {bookking_slots} s
        WHERE
        s.bookkingid = ? AND
        u.id = s.teacherid
        ';
    $teachers = $DB->get_records_sql($sql, array($bookkingid));

    if ($students and $teachers){
        $participants = array_merge(array_values($students), array_values($teachers));
    }
    elseif ($students) {
        $participants = array_values($students);
    }
    elseif ($teachers){
        $participants = array_values($teachers);
    }
    else{
        $participants = array();
    }

    //Return students array (it contains an array of unique users)
    return ($participants);
}

/**
 * This function returns if a scale is being used by one newmodule
 * it it has support for grading and scales. Commented code should be
 * modified if necessary. See forum, glossary or journal modules
 * as reference.
 *
 * @param int $newmoduleid ID of an instance of this module
 * @return mixed
 * @uses $DB
 **/
function bookking_scale_used($cmid, $scaleid) {
    global $DB;

    $return = false;

    // Note: scales are assigned using negative index in the grade field of the appointment (see mod/assignement/lib.php).
    $rec = $DB->get_record('bookking', array('id' => $cmid, 'scale' => -$scaleid));

    if (!empty($rec) && !empty($scaleid)) {
        $return = true;
    }

    return $return;
}


/**
 * Checks if scale is being used by any instance of bookking
 *
 * This is used to find out if scale used anywhere
 * @param $scaleid int
 * @return boolean True if the scale is used by any bookking
 */
function bookking_scale_used_anywhere($scaleid) {
    global $DB;

    if ($scaleid and $DB->record_exists('bookking', array('scale' => -$scaleid))) {
        return true;
    } else {
        return false;
    }
}


/*
 * Course resetting API
 *
 */

/**
 * Called by course/reset.php
 * @param $mform form passed by reference
 */
function bookking_reset_course_form_definition(&$mform) {
    global $COURSE, $DB;

    $mform->addElement('header', 'bookkingheader', get_string('modulenameplural', 'bookking'));

    if($DB->record_exists('bookking', array('course'=>$COURSE->id))){

        $mform->addElement('checkbox', 'reset_bookking_slots', get_string('resetslots', 'bookking'));
        $mform->addElement('checkbox', 'reset_bookking_appointments', get_string('resetappointments', 'bookking'));
        $mform->disabledIf('reset_bookking_appointments', 'reset_bookking_slots', 'checked');
    }
}

/**
 * Default values for the reset form
 */
function bookking_reset_course_form_defaults($course) {
    return array('reset_bookking_slots'=>1, 'reset_bookking_appointments'=>1);
}


/**
 * This function is used by the remove_course_userdata function in moodlelib.
 * If this function exists, remove_course_userdata will execute it.
 * This function will remove all posts from the specified forum.
 * @param data the reset options
 * @return void
 */
function bookking_reset_userdata($data) {
    global $CFG, $DB;

    $status = array();
    $componentstr = get_string('modulenameplural', 'bookking');

    $sqlfromslots = 'FROM {bookking_slots} WHERE bookkingid IN '.
        '(SELECT sc.id FROM {bookking} sc '.
        ' WHERE sc.course = :course)';

    $params = array('course'=>$data->courseid);

    $strreset = get_string('reset');

    if (!empty($data->reset_bookking_appointments) || !empty($data->reset_bookking_slots)) {

        $slots = $DB->get_recordset_sql('SELECT * '.$sqlfromslots, $params);
        $success = true;
        foreach ($slots as $slot) {
            // delete calendar events
            $success = $success && bookking_delete_calendar_events($slot);

            // delete appointments
            $success = $success && $DB->delete_records('bookking_appointment', array('slotid'=>$slot->id));
        }
        $slots->close();

        // Reset gradebook.
        $bookkings = $DB->get_records('bookking', $params);
        foreach ($bookkings as $bookking) {
            bookking_grade_item_update($bookking, 'reset');
        }

        $status[] = array('component' => $componentstr, 'item' => get_string('resetappointments','bookking'), 'error' => !$success);
    }
    if (!empty($data->reset_bookking_slots)) {
        if ($DB->execute('DELETE '.$sqlfromslots, $params)) {
            $status[] = array('component' => $componentstr, 'item' => get_string('resetslots','bookking'), 'error' => false);
        }
    }
    return $status;
}

/**
 * @param string $feature FEATURE_xx constant for requested feature
 * @return mixed True if module supports feature, null if doesn't know
 */
function bookking_supports($feature) {
    switch($feature) {
        case FEATURE_GROUPS:                  return true;
        case FEATURE_GROUPINGS:               return true;
        case FEATURE_GROUPMEMBERSONLY:        return true;
        case FEATURE_MOD_INTRO:               return true;
        case FEATURE_COMPLETION_TRACKS_VIEWS: return false;
        case FEATURE_GRADE_HAS_GRADE:         return true;
        case FEATURE_GRADE_OUTCOMES:          return false;
        case FEATURE_BACKUP_MOODLE2:          return true;

        default: return null;
    }
}

/* Gradebook API */
/*
 * add xxx_update_grades() function into mod/xxx/lib.php
 * add xxx_grade_item_update() function into mod/xxx/lib.php
 * patch xxx_update_instance(), xxx_add_instance() and xxx_delete_instance() to call xxx_grade_item_update()
 * patch all places of code that change grade values to call xxx_update_grades()
 * patch code that displays grades to students to use final grades from the gradebook
 */

/**
 * Update activity grades
 *
 * @param object $bookking
 * @param int $userid specific user only, 0 means all
 */
function bookking_update_grades($bookkingrecord, $userid=0, $nullifnone=true) {
    global $CFG, $DB;
    require_once($CFG->libdir.'/gradelib.php');

    $bookking = bookking_instance::load_by_id($bookkingrecord->id);

    if ($bookking->scale == 0) {
        bookking_grade_item_update($bookkingrecord);

    } else if ($grades = $bookking->get_user_grades($userid)) {
        foreach ($grades as $k => $v) {
            if ($v->rawgrade == -1) {
                $grades[$k]->rawgrade = null;
            }
        }
        bookking_grade_item_update($bookkingrecord, $grades);

    } else {
        bookking_grade_item_update($bookkingrecord);
    }
}


/**
 * Create grade item for given bookking
 *
 * @param object $bookking object
 * @param mixed optional array/object of grade(s); 'reset' means reset grades in gradebook
 * @return int 0 if ok, error code otherwise
 */
function bookking_grade_item_update($bookking, $grades=null) {
    global $CFG, $DB;
    require_once($CFG->libdir.'/gradelib.php');

    if (!isset($bookking->courseid)) {
        $bookking->courseid = $bookking->course;
    }
    $moduleid = $DB->get_field('modules', 'id', array('name' => 'bookking'));
    $cmid = $DB->get_field('course_modules', 'id', array('module' => $moduleid, 'instance' => $bookking->id));

    if ($bookking->scale == 0) {
        // Delete any grade item.
        bookking_grade_item_delete($bookking);
        return 0;
    } else {
        $params = array('itemname' => $bookking->name, 'idnumber' => $cmid);

        if ($bookking->scale > 0) {
            $params['gradetype'] = GRADE_TYPE_VALUE;
            $params['grademax']  = $bookking->scale;
            $params['grademin']  = 0;

        } else if ($bookking->scale < 0) {
            $params['gradetype'] = GRADE_TYPE_SCALE;
            $params['scaleid']   = -$bookking->scale;

        } else {
            $params['gradetype'] = GRADE_TYPE_TEXT; // Allow text comments only.
        }

        if ($grades === 'reset') {
            $params['reset'] = true;
            $grades = null;
        }

        return grade_update('mod/bookking', $bookking->courseid, 'mod', 'bookking', $bookking->id, 0, $grades, $params);
    }
}



/**
 * Update all grades in gradebook.
 */
function bookking_upgrade_grades() {
    global $DB;

    $sql = "SELECT COUNT('x')
        FROM {bookking} s, {course_modules} cm, {modules} m
        WHERE m.name='bookking' AND m.id=cm.module AND cm.instance=s.id";
    $count = $DB->count_records_sql($sql);

    $sql = "SELECT s.*, cm.idnumber AS cmidnumber, s.course AS courseid
        FROM {bookking} s, {course_modules} cm, {modules} m
        WHERE m.name='bookking' AND m.id=cm.module AND cm.instance=s.id";
    $rs = $DB->get_recordset_sql($sql);
    if ($rs->valid()) {
        $pbar = new progress_bar('bookkingupgradegrades', 500, true);
        $i = 0;
        foreach ($rs as $bookking) {
            $i++;
            upgrade_set_timeout(60 * 5); // Set up timeout, may also abort execution.
            bookking_update_grades($bookking);
            $pbar->update($i, $count, "Updating bookking grades ($i/$count).");
        }
        upgrade_set_timeout(); // Reset to default timeout.
    }
    $rs->close();
}


/**
 * Delete grade item for given bookking
 *
 * @param object $bookking object
 * @return object bookking
 */
function bookking_grade_item_delete($bookking) {
    global $CFG;
    require_once($CFG->libdir.'/gradelib.php');

    if (!isset($bookking->courseid)) {
        $bookking->courseid = $bookking->course;
    }

    return grade_update('mod/bookking', $bookking->courseid, 'mod', 'bookking', $bookking->id, 0, null, array('deleted' => 1));
}

