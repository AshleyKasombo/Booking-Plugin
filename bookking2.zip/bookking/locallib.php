<?php

defined('MOODLE_INTERNAL') || die();

require_once(dirname(__FILE__).'/customlib.php');

require_once(dirname(__FILE__).'/model/bookking_instance.php');
require_once(dirname(__FILE__).'/model/bookking_slot.php');
require_once(dirname(__FILE__).'/model/bookking_appointment.php');


/**
 * get list of attendants for slot form
 * @param int $cmid the course module
 * @param mixed $groupid id number of the group to select from, 0 or '' if all groups
 * @return array of moodle user records
 */
function bookking_get_attendants($cmid, $groupid='') {
    $context = context_module::instance($cmid);
    if (!$groupid) {
        $groupkeys = '';
    } else {
        $groupkeys = array($groupid);
    }
    $attendants = get_users_by_capability ($context, 'mod/bookking:attend',
        user_picture::fields('u'), 'u.lastname, u.firstname',
        '', '', $groupkeys, '', false, false, false);
    return $attendants;
}

/**
 * Returns an array of slots that would overlap with this one.
 * @param int $bookkingid the current activity module id
 * @param int $starttimethe start of time slot as a timestamp
 * @param int $endtime end of time slot as a timestamp
 * @param int $teacher if not null, the id of the teacher constraint, 0 otherwise standas for "all teachers"
 * @param int $others selects where to search for conflicts, [bookking_SELF, bookking_OTHERS, bookking_ALL]
 * @param boolean $careexclusive if false, conflict will consider all slots wether exlusive or not. Use it for testing if user is appointed in the given scope.
 * @uses $CFG
 * @uses $DB
 * @return array array of conflicting slots
 */
function bookking_get_conflicts($bookkingid, $starttime, $endtime, $teacher=0, $student=0, $others=bookking_SELF, $careexclusive=true) {
    global $CFG, $DB;

    switch ($others){
        case bookking_SELF:
            $bookkingScope = "s.bookkingid = {$bookkingid} AND ";
            break;
        case bookking_OTHERS:
            $bookkingScope = "s.bookkingid != {$bookkingid} AND ";
            break;
        default:
            $bookkingScope = '';
    }
    $teacherScope = ($teacher != 0) ? "s.teacherid = {$teacher} AND " : '' ;
    $studentJoin = ($student != 0) ? "JOIN {bookking_appointment} a ON a.slotid = s.id AND a.studentid = {$student} " : '' ;
    $exclusiveClause = ($careexclusive) ? "exclusivity != 0 AND " : '' ;
    $timeClause = "( (s.starttime <= {$starttime} AND s.starttime + s.duration * 60 > {$starttime}) OR ".
        "  (s.starttime < {$endtime} AND s.starttime + s.duration * 60 >= {$endtime}) OR ".
        "  (s.starttime >= {$starttime} AND s.starttime + s.duration * 60 <= {$endtime}) ) ";

    $sql = 'SELECT s.* from {bookking_slots} s '.$studentJoin.' WHERE '.
        $bookkingScope.$teacherScope.$exclusiveClause.$timeClause;

    $conflicting = $DB->get_records_sql($sql);

    return $conflicting;
}


/**
 * checks if user has an appointment in this bookking
 * @param object $userlist
 * @param object $bookking
 * @param boolean $student, if true, is a student, a teacher otherwise
 * @param boolean $unattended, if true, only checks for unattended slots
 * @param string $otherthan giving a slotid, excludes this slot from the search
 * @uses $CFG
 * @uses $DB
 * @return the count of records
 */
function bookking_has_slot($userlist, &$bookking, $student=true, $unattended = false, $otherthan = 0){
    global $CFG, $DB;

    $userlist = str_replace(',', "','", $userlist);

    $unattendedClause = ($unattended) ? ' AND a.attended = 0 ' : '' ;
    $otherthanClause = ($otherthan) ? " AND a.slotid != $otherthan " : '' ;

    if ($student){
        $sql = "
            SELECT
            COUNT(*)
            FROM
            {bookking_slots} s,
            {bookking_appointment} a
            WHERE
            a.slotid = s.id AND
            s.bookkingid = ? AND
            a.studentid IN ('{$userlist}')
            $unattendedClause
            $otherthanClause
            ";
        return $DB->count_records_sql($sql, array($bookking->id));
    } else {
        return $DB->count_records('bookking_slots', array('teacherid' => $userlist, 'bookkingid' => $bookking->id));
    }
}

/**
 * returns an array of appointed user records for a certain slot.
 * @param int $slotid
 * @uses $CFG
 * @uses $DB
 * @return an array of users
 */
function bookking_get_appointed($slotid){
    global $CFG, $DB;

    $sql = "
        SELECT
        u.*
        FROM
        {user} u,
        {bookking_appointment} a
        WHERE
        u.id = a.studentid AND
        a.slotid = ?
        ";
    return $DB->get_records_sql($sql, array($slotid));
}


/// Events related functions

/**
 * Will delete calendar events for a given bookking slot, and not complain if the record does not exist.
 * The only argument this function requires is the complete database record of a bookking slot.
 * @param object $slot the slot instance
 * @uses $DB
 * @return boolean true if success, false otherwise
 */
function bookking_delete_calendar_events($slot) {
    global $DB;

    $bookking = $DB->get_record('bookking', array('id' => $slot->bookkingid));

    if (!$bookking) return false ;

    $teacherEventType = "SSsup:{$slot->id}:{$bookking->course}";
    $studentEventType = "SSstu:{$slot->id}:{$bookking->course}";

    $teacherDeletionSuccess = $DB->delete_records('event', array('eventtype'=>$teacherEventType));
    $studentDeletionSuccess = $DB->delete_records('event', array('eventtype'=>$studentEventType));

    return ($teacherDeletionSuccess && $studentDeletionSuccess);
    //this return may not be meaningful if the delete records functions do not return anything meaningful.
}


/**
 * Construct an array with subtitution rules for mail templates, relating to
 * a single appointment. Any of the parameters can be null.
 * @param bookking_instance $bookking The bookking instance
 * @param bookking_slot $slot The slot data as an MVC object
 * @param user $attendant A {@link $USER} object describing the attendant (teacher)
 * @param user $attendee A {@link $USER} object describing the attendee (student)
 * @param object $course A course object relating to the ontext of the message
 * @param object $recipient A {@link $USER} object describing the recipient of the message (used for determining the message language)
 * @return array A hash with mail template substitutions
 */
function bookking_get_mail_variables (bookking_instance $bookking, bookking_slot $slot, $attendant, $attendee, $course, $recipient) {

    global $CFG;

    $lang = bookking_get_message_language($recipient, $course);
    // Force any string formatting to happen in the target language.
    $oldlang = force_current_language($lang);

    $tz = core_date::get_user_timezone($recipient);

    $vars = array();

    if ($bookking) {
        $vars['MODULE']     = $bookking->name;
        $vars['STAFFROLE']  = $bookking->get_teacher_name();
        $vars['bookking_URL'] = $CFG->wwwroot.'/mod/bookking/view.php?id='.$bookking->cmid;
    }
    if ($slot) {
        $vars ['DATE']     = userdate($slot->starttime, get_string('strftimedate'), $tz);
        $vars ['TIME']     = userdate($slot->starttime, get_string('strftimetime'), $tz);
        $vars ['ENDTIME']  = userdate($slot->endtime, get_string('strftimetime'), $tz);
        $vars ['LOCATION'] = format_string($slot->appointmentlocation);
    }
    if ($attendant) {
        $vars['ATTENDANT']     = fullname($attendant);
        $vars['ATTENDANT_URL'] = $CFG->wwwroot.'/user/view.php?id='.$attendant->id.'&course='.$bookking->course;
    }
    if ($attendee) {
        $vars['ATTENDEE']     = fullname($attendee);
        $vars['ATTENDEE_URL'] = $CFG->wwwroot.'/user/view.php?id='.$attendee->id.'&course='.$bookking->course;
    }

    // Reset language settings.
    force_current_language($oldlang);

    return $vars;

}

/**
 * Prints a summary of a user in a nice little box.
 *
 * @uses $CFG
 * @uses $USER
 * @param user $user A {@link $USER} object representing a user
 * @param course $course A {@link $COURSE} object representing a course
 */
function bookking_print_user($user, $course, $messageselect=false, $return=false) {

    global $CFG, $USER, $OUTPUT;

    $output = '';

    static $string;
    static $datestring;
    static $countries;

    $context = context_course::instance($course->id);
    if (isset($user->context->id)) {
        $usercontext = $user->context;
    } else {
        $usercontext = context_user::instance($user->id);
    }

    if (empty($string)) {     // Cache all the strings for the rest of the page

        $string = new stdClass();
        $string->email       = get_string('email');
        $string->lastaccess  = get_string('lastaccess');
        $string->activity    = get_string('activity');
        $string->loginas     = get_string('loginas');
        $string->fullprofile = get_string('fullprofile');
        $string->role        = get_string('role');
        $string->name        = get_string('name');
        $string->never       = get_string('never');

        $datestring = new stdClass();
        $datestring->day     = get_string('day');
        $datestring->days    = get_string('days');
        $datestring->hour    = get_string('hour');
        $datestring->hours   = get_string('hours');
        $datestring->min     = get_string('min');
        $datestring->mins    = get_string('mins');
        $datestring->sec     = get_string('sec');
        $datestring->secs    = get_string('secs');
        $datestring->year    = get_string('year');
        $datestring->years   = get_string('years');

    }

    /// Get the hidden field list
    if (has_capability('moodle/course:viewhiddenuserfields', $context)) {
        $hiddenfields = array();
    } else {
        $hiddenfields = array_flip(explode(',', $CFG->hiddenuserfields));
    }

    $output .= '<table class="userinfobox">';
    $output .= '<tr>';
    $output .= '<td class="left side">';
    $output .= $OUTPUT->user_picture($user, array('size'=>100));
    $output .= '</td>';
    $output .= '<td class="content">';
    $output .= '<div class="username">'.fullname($user, has_capability('moodle/site:viewfullnames', $context)).'</div>';
    $output .= '<div class="info">';
    if (!empty($user->role) and ($user->role <> $course->teacher)) {
        $output .= $string->role .': '. $user->role .'<br />';
    }

    $extrafields = bookking_get_user_fields($user);
    foreach ($extrafields as $field) {
        $output .= $field->title . ': ' . $field->value . '<br />';
    }


    if (!isset($hiddenfields['lastaccess'])) {
        if ($user->lastaccess) {
            $output .= $string->lastaccess .': '. userdate($user->lastaccess);
            $output .= '&nbsp; ('. format_time(time() - $user->lastaccess, $datestring) .')';
        } else {
            $output .= $string->lastaccess .': '. $string->never;
        }
    }
    $output .= '</div></td><td class="links">';
    //link to blogs
    if ($CFG->bloglevel > 0) {
        $output .= '<a href="'.$CFG->wwwroot.'/blog/index.php?userid='.$user->id.'">'.get_string('blogs','blog').'</a><br />';
    }
    //link to notes
    if (!empty($CFG->enablenotes) and (has_capability('moodle/notes:manage', $context) || has_capability('moodle/notes:view', $context))) {
        $output .= '<a href="'.$CFG->wwwroot.'/notes/index.php?course=' . $course->id. '&amp;user='.$user->id.'">'.get_string('notes','notes').'</a><br />';
    }

    if (has_capability('moodle/site:viewreports', $context) or has_capability('moodle/user:viewuseractivitiesreport', $usercontext)) {
        $output .= '<a href="'. $CFG->wwwroot .'/course/user.php?id='. $course->id .'&amp;user='. $user->id .'">'. $string->activity .'</a><br />';
    }
    $output .= '<a href="'. $CFG->wwwroot .'/user/profile.php?id='. $user->id .'">'. $string->fullprofile .'...</a>';

    if (!empty($messageselect)) {
        $output .= '<br /><input type="checkbox" name="user'.$user->id.'" /> ';
    }

    $output .= '</td></tr></table>';

    if ($return) {
        return $output;
    } else {
        echo $output;
    }
}


function bookking_has_teachers($context) {
    $teachers = get_users_by_capability ($context, 'mod/bookking:attend', 'u.id');
    return count($teachers) > 0;
}


