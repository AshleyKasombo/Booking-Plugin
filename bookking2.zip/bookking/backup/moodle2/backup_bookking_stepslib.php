<?php


/**
 * Define all the backup steps that will be used by the backup_bookking_activity_task
 */

/**
 * Define the complete bookking structure for backup, with file and id annotations
 */
class backup_bookking_activity_structure_step extends backup_activity_structure_step {

    protected function define_structure() {

        // To know if we are including userinfo
        $userinfo = $this->get_setting_value('userinfo');

        // Define each element separated
        $bookking = new backup_nested_element('bookking', array('id'), array(
            'name', 'intro', 'introformat', 'bookkingmode', 'maxbookings',
            'guardtime', 'defaultslotduration', 'allownotifications', 'staffrolename',
            'scale', 'gradingstrategy', 'bookingrouping', 'timemodified'));

        $slots = new backup_nested_element('slots');

        $slot = new backup_nested_element('slot', array('id'), array(
            'starttime', 'duration', 'teacherid', 'appointmentlocation',
            'timemodified', 'notes', 'exclusivity',
            'appointmentnote', 'emaildate', 'hideuntil'));

        $appointments = new backup_nested_element('appointments');

        $appointment = new backup_nested_element('appointment', array('id'), array(
            'studentid', 'attended', 'grade', 'appointmentnote',
            'timecreated', 'timemodified'));

        // Build the tree

        $bookking->add_child($slots);
        $slots->add_child($slot);

        $slot->add_child($appointments);
        $appointments->add_child($appointment);


        // Define sources
        $bookking->set_source_table('bookking', array('id' => backup::VAR_ACTIVITYID));
		$bookking->annotate_ids('grouping', 'bookingrouping');

        // Include appointments only if we back up user information
        if ($userinfo) {
            $slot->set_source_table('bookking_slots', array('bookkingid' => backup::VAR_PARENTID));
            $appointment->set_source_table('bookking_appointment', array('slotid' => backup::VAR_PARENTID));
        }

        // Define id annotations
        $bookking->annotate_ids('scale', 'scale');

        if ($userinfo) {
            $slot->annotate_ids('user', 'teacherid');
            $appointment->annotate_ids('user', 'studentid');
        }

        // Define file annotations
        $bookking->annotate_files('mod_bookking', 'intro', null); // This file area has no itemid

        // Return the root element (bookking), wrapped into standard activity structure
        return $this->prepare_activity_structure($bookking);
    }
}
