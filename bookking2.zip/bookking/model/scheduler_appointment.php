<?php


defined('MOODLE_INTERNAL') || die();

require_once('modellib.php');



    protected function get_table() {
        return 'bookking_appointment';
    }

    public function __construct(bookking_slot $slot) {
        parent::__construct();
        $this->data = new stdClass();
        $this->set_parent($slot);
        $this->data->slotid = $slot->get_id();
        $this->data->attended = 0;
        $this->data->appointmentnoteformat = FORMAT_HTML;
    }

    public function save() {
        $this->data->slotid = $this->get_parent()->get_id();
        parent::save();
        $scheddata = $this->get_bookking()->get_data();
        bookking_update_grades($scheddata, $this->studentid);
    }

    public function delete() {
        $studid = $this->studentid;
        parent::delete();
        $scheddata = $this->get_bookking()->get_data();
        bookking_update_grades($scheddata, $studid);
    }

    public function get_bookking() {
        return $this->get_parent()->get_parent();
    }

    /**
     * Return the student object.
     * May be null if no student is assigned to this appointment (this _should_ never happen).
     */
    public function get_student() {
        global $DB;
        if ($this->data->studentid) {
            return $DB->get_record('user', array('id' => $this->data->studentid), '*', MUST_EXIST);
        } else {
            return null;
        }
    }

    /**
     * Has this student attended?
     */
    public function is_attended() {
        return (boolean) $this->data->attended;
    }

}

class bookking_appointment_factory extends mvc_child_model_factory {
    public function create_child(mvc_record_model $parent) {
        return new bookking_appointment($parent);
    }
}
