<?php

defined('MOODLE_INTERNAL') || die();

require_once($CFG->dirroot.'/mod/bookking/mailtemplatelib.php');

$returnurl = new moodle_url('/mod/bookking/view.php', array('id' => $cm->id));

/************************************************ Book a slot  ************************************************/

if ($action == 'bookslot') {

    require_sesskey();

    // Get the request parameters.
    $slotid = required_param('slotid', PARAM_INT);
    $slot = $bookking->get_slot($slotid);
    if (!$slot) {
        throw new moodle_exception('error');
    }

    if (!$slot->is_in_bookable_period()) {
        throw new moodle_exception('nopermissions');
    }

    $requiredcapacity = 1;
    $userstobook = array($USER->id);
    if ($appointgroup) {
        $groupmembers = $bookking->get_possible_attendees(array($appointgroup));
        $requiredcapacity = count($groupmembers);
        $userstobook = array_keys($groupmembers);
    }

    $errormessage = '';

    $bookinglimit = $bookking->count_bookable_appointments($USER->id, false);
    if ($bookinglimit == 0) {
        $errormessage = get_string('selectedtoomany', 'bookking', $bookinglimit);
    }
    if (!$errormessage) {
        // Validate our user ids.
        $existingstudents = array();
        foreach ($slot->get_appointments() as $app) {
            $existingstudents[] = $app->studentid;
        }
        $userstobook = array_diff($userstobook, $existingstudents);

        $remaining = $slot->count_remaining_appointments();
        // If the slot is already overcrowded...
        if ($remaining >= 0 && $remaining < $requiredcapacity) {
            if ($requiredcapacity > 1) {
                $errormessage = get_string('notenoughplaces', 'bookking');
            } else {
                $errormessage = get_string('slot_is_just_in_use', 'bookking');
            }
        }
    }

    if ($errormessage) {
        echo $output->header();
        echo $output->box($errormessage, 'error');
        echo $output->continue_button($returnurl);
        echo $output->footer();
        exit();
    }

    // Create new appointment and add it for each member of the group.
    foreach ($userstobook as $studentid) {
        $appointment = $slot->create_appointment();
        $appointment->studentid = $studentid;
        $appointment->attended = 0;
        $appointment->timecreated = time();
        $appointment->timemodified = time();

        \mod_bookking\event\booking_added::create_from_slot($slot)->trigger();

        // Notify the teacher.
        if ($bookking->allownotifications) {
            $student = $DB->get_record('user', array('id' => $appointment->studentid));
            $teacher = $DB->get_record('user', array('id' => $slot->teacherid));
            $vars = bookking_get_mail_variables($bookking, $slot, $teacher, $student, $course, $teacher);
            bookking_send_email_from_template($teacher, $student, $course, 'newappointment', 'applied', $vars, 'bookking');
        }
    }
    $slot->save();
    redirect($returnurl);
}


/******************************** Cancel a booking (for the current student or a group) ******************************/

if ($action == 'cancelbooking') {

    require_sesskey();

    // Get the request parameters.
    $slotid = required_param('slotid', PARAM_INT);
    $slot = $bookking->get_slot($slotid);
    if (!$slot) {
        throw new moodle_exception('error');
    }

    if (!$slot->is_in_bookable_period()) {
        throw new moodle_exception('nopermissions');
    }

    require_capability('mod/bookking:appoint', $context);

    $userstocancel = array($USER->id);
    if ($appointgroup) {
        $userstocancel = array_keys($bookking->get_possible_attendees(array($appointgroup)));
    }

    foreach ($userstocancel as $userid) {
        if ($appointment = $slot->get_student_appointment($userid)) {
            $bookking->delete_appointment($appointment->id);

            // Notify the teacher.
            if ($bookking->allownotifications) {
                $student = $DB->get_record('user', array('id' => $USER->id));
                $teacher = $DB->get_record('user', array('id' => $slot->teacherid));
                $vars = bookking_get_mail_variables($bookking, $slot, $teacher, $student, $course, $teacher);
                bookking_send_email_from_template($teacher, $student, $COURSE,
                                                   'cancelledbystudent', 'cancelled', $vars, 'bookking');
            }
            \mod_bookking\event\booking_removed::create_from_slot($slot)->trigger();
        }
    }
    redirect($returnurl);

}
