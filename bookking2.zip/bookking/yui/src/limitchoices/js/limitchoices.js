
M.mod_bookking = M.mod_bookking || {};
MOD = M.mod_bookking.limitchoices = {};

MOD.allSlotboxes = function() {
	return Y.all('table#slotbookertable input.slotbox');
};

MOD.checkLimits = function(maxchecked) {
	checkedcnt = 0;
	this.allSlotboxes().each( function(box) {
		if (box.get('checked')) {
			checkedcnt++;
		}
	});
	disableunchecked = (checkedcnt >= maxchecked);
	this.allSlotboxes().each( function(box) {
		disablebox = !box.get('checked') && disableunchecked;
        box.set('disabled', disablebox);
    });
};

MOD.init = function(maxchecked) {
	this.checkLimits(maxchecked);
	this.allSlotboxes().on('change', function() {
		M.mod_bookking.limitchoices.checkLimits(maxchecked);
	});
};
