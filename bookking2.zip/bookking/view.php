<?php

require_once(dirname(__FILE__) . '/../../config.php');
require_once($CFG->dirroot.'/mod/bookking/lib.php');
require_once($CFG->dirroot.'/mod/bookking/locallib.php');
require_once($CFG->dirroot.'/mod/bookking/renderable.php');

// Read common request parameters.
$id = optional_param('id', '', PARAM_INT);    // Course Module ID - if it's not specified, must specify 'a', see below.
$action = optional_param('what', 'view', PARAM_ALPHA);
$subaction = optional_param('subaction', '', PARAM_ALPHA);
$offset = optional_param('offset', -1, PARAM_INT);

if ($id) {
    $cm = get_coursemodule_from_id('bookking', $id, 0, false, MUST_EXIST);
    $bookking = bookking_instance::load_by_coursemodule_id($id);
} else {
    $a = required_param('a', PARAM_INT);     // bookking ID.
    $bookking = bookking_instance::load_by_id($a);
    $cm = $bookking->get_cm();
}
$course = $DB->get_record('course', array('id' => $cm->course), '*', MUST_EXIST);

$defaultsubpage = groups_get_activity_groupmode($cm) ? 'myappointments' : 'allappointments';
$subpage = optional_param('subpage', $defaultsubpage, PARAM_ALPHA);

require_login($course->id, false, $cm);
$context = context_module::instance($cm->id);
// TODO require_capability('mod/bookking:view', $context);

// Initialize $PAGE, compute blocks.
$PAGE->set_url('/mod/bookking/view.php', array('id' => $cm->id));

$output = $PAGE->get_renderer('mod_bookking');

// Print the page header.

$strbookkings = get_string('modulenameplural', 'bookking');
$strbookking  = get_string('modulename', 'bookking');
$strtime = get_string('time');
$strdate = get_string('date', 'bookking');
$strstart = get_string('start', 'bookking');
$strend = get_string('end', 'bookking');
$strname = get_string('name');
$strseen = get_string('seen', 'bookking');
$strnote = get_string('comments', 'bookking');
$strgrade = get_string('grade', 'bookking');
$straction = get_string('action', 'bookking');
$strduration = get_string('duration', 'bookking');
$stremail = get_string('email');

$title = $course->shortname . ': ' . format_string($bookking->name);
$PAGE->set_title($title);
$PAGE->set_heading($course->fullname);


// route to screen

// teacher side
if (has_capability('mod/bookking:manage', $context)) {
    if ($action == 'viewstatistics') {
        include($CFG->dirroot.'/mod/bookking/viewstatistics.php');
    } else if ($action == 'viewstudent') {
        include($CFG->dirroot.'/mod/bookking/viewstudent.php');
    } else if ($action == 'export') {
        include($CFG->dirroot.'/mod/bookking/export.php');
    } else if ($action == 'datelist') {
        include($CFG->dirroot.'/mod/bookking/datelist.php');
    } else {
        include($CFG->dirroot.'/mod/bookking/teacherview.php');
    }

    // student side
} else if (has_capability('mod/bookking:appoint', $context)) {
    include($CFG->dirroot.'/mod/bookking/studentview.php');

    // for guests
} else {
    echo $OUTPUT->header();
    echo $OUTPUT->box(get_string('guestscantdoanything', 'bookking'), 'generalbox');
    echo $OUTPUT->footer($course);
}
