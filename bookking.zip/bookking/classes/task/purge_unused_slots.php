<?php

/**
 * Scheduled background task for sending automated appointment reminders
 *
 * @package    mod_bookking
 * @copyright  2016 Henning Bostelmann and others (see README.txt)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_bookking\task;

defined('MOODLE_INTERNAL') || die();

require_once(dirname(__FILE__).'/../../model/bookking_instance.php');

/**
 * Scheduled background task for sending automated appointment reminders
 *
 * @package    mod_bookking
 * @copyright  2016 Henning Bostelmann and others (see README.txt)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
 class purge_unused_slots extends \core\task\scheduled_task {
    public function get_name() {
        return get_string('purgeunusedslots', 'mod_bookking');
    }

    public function execute() {
        \bookking_instance::free_late_unused_slots();
    }
}
