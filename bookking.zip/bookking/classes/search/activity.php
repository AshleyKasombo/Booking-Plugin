<?php

/**
 * Search area for BookKing activities.
 *
 * @package    mod_bookking
 * @copyright  2016 Henning Bostelmann and others (see README.txt)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_bookking\search;

defined('MOODLE_INTERNAL') || die();

/**
 * Search area for mod_bookking activities.
 *
 * This covers the activity description and intro section only.
 * @copyright  2016 Henning Bostelmann and others (see README.txt)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class activity extends \core_search\base_activity {
}
