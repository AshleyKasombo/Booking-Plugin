<?php

/**
 * Define all the backup steps that will be used by the backup_bookking_activity_task
 *
 * @package    mod_bookking
 * @copyright  2016 Henning Bostelmann and others (see README.txt)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * Define the complete bookking structure for backup, with file and id annotations
 *
 * @copyright  2016 Henning Bostelmann and others (see README.txt)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class backup_bookking_activity_structure_step extends backup_activity_structure_step {

    protected function define_structure() {

        // To know if we are including userinfo.
        $userinfo = $this->get_setting_value('userinfo');

        // Define each element separated.
        $bookking = new backup_nested_element('bookking', array('id'), array(
            'name', 'intro', 'introformat', 'bookkingmode', 'maxbookings',
            'guardtime', 'defaultslotduration', 'allownotifications', 'staffrolename',
            'scale', 'gradingstrategy', 'bookingrouping', 'usenotes',
            'usebookingform', 'bookinginstructions', 'bookinginstructionsformat',
            'usestudentnotes', 'requireupload', 'uploadmaxfiles', 'uploadmaxsize',
            'usecaptcha', 'timemodified'));

        $slots = new backup_nested_element('slots');

        $slot = new backup_nested_element('slot', array('id'), array(
            'starttime', 'duration', 'teacherid', 'appointmentlocation',
            'timemodified', 'notes', 'notesformat', 'exclusivity',
            'emaildate', 'hideuntil'));

        $appointments = new backup_nested_element('appointments');

        $appointment = new backup_nested_element('appointment', array('id'), array(
            'studentid', 'attended', 'grade',
            'appointmentnote', 'appointmentnoteformat', 'teachernote', 'teachernoteformat',
            'studentnote', 'studentnoteformat', 'timecreated', 'timemodified'));

        // Build the tree.

        $bookking->add_child($slots);
        $slots->add_child($slot);

        $slot->add_child($appointments);
        $appointments->add_child($appointment);

        // Define sources.
        $bookking->set_source_table('bookking', array('id' => backup::VAR_ACTIVITYID));
        $bookking->annotate_ids('grouping', 'bookingrouping');

        // Include appointments only if we back up user information.
        if ($userinfo) {
            $slot->set_source_table('bookking_slots', array('bookkingid' => backup::VAR_PARENTID));
            $appointment->set_source_table('bookking_appointment', array('slotid' => backup::VAR_PARENTID));
        }

        // Define id annotations.
        $bookking->annotate_ids('scale', 'scale');

        if ($userinfo) {
            $slot->annotate_ids('user', 'teacherid');
            $appointment->annotate_ids('user', 'studentid');
        }

        // Define file annotations.
        $bookking->annotate_files('mod_bookking', 'intro', null); // Files stored in intro field.
        $bookking->annotate_files('mod_bookking', 'bookinginstructions', null); // Files stored in intro field.
        $slot->annotate_files('mod_bookking', 'slotnote', 'id'); // Files stored in slot notes.
        $appointment->annotate_files('mod_bookking', 'appointmentnote', 'id'); // Files stored in appointment notes.
        $appointment->annotate_files('mod_bookking', 'teachernote', 'id'); // Files stored in teacher-only notes.
        $appointment->annotate_files('mod_bookking', 'studentfiles', 'id'); // Files uploaded by students.

        // Return the root element (bookking), wrapped into standard activity structure.
        return $this->prepare_activity_structure($bookking);
    }
}
