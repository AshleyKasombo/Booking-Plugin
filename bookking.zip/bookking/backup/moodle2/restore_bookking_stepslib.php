<?php

/**
 * Define all the restore steps that will be used by the restore_bookking_activity_task
 *
 * @package    mod_bookking
 * @copyright  2016 Henning Bostelmann and others (see README.txt)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * Structure step to restore one bookking activity
 *
 * @copyright  2016 Henning Bostelmann and others (see README.txt)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class restore_bookking_activity_structure_step extends restore_activity_structure_step {

    protected function define_structure() {

        $paths = array();
        $userinfo = $this->get_setting_value('userinfo');

        $bookking = new restore_path_element('bookking', '/activity/bookking');
        $paths[] = $bookking;

        if ($userinfo) {
            $slot = new restore_path_element('bookking_slot', '/activity/bookking/slots/slot');
            $paths[] = $slot;

            $appointment = new restore_path_element('bookking_appointment',
                                                    '/activity/bookking/slots/slot/appointments/appointment');
            $paths[] = $appointment;
        }

        // Return the paths wrapped into standard activity structure.
        return $this->prepare_activity_structure($paths);
    }

    protected function process_bookking($data) {
        global $DB;

        $data = (object)$data;
        $oldid = $data->id;
        $data->course = $this->get_courseid();

        $data->timemodified = $this->apply_date_offset($data->timemodified);

        if ($data->scale < 0) { // Scale found, get mapping.
            $data->scale = -($this->get_mappingid('scale', abs($data->scale)));
        }

        if (is_null($data->gradingstrategy)) { // Catch inconsistent data created by pre-1.9 DB schema.
            $data->gradingstrategy = 0;
        }

        if ($data->bookingrouping > 0) {
            $data->bookingrouping = $this->get_mappingid('grouping', $data->bookingrouping);
        }

        // Insert the bookking record.
        $newitemid = $DB->insert_record('bookking', $data);
        // Immediately after inserting "activity" record, call this.
        $this->apply_activity_instance($newitemid);
    }

    protected function process_bookking_slot($data) {
        global $DB;

        $data = (object)$data;
        $oldid = $data->id;

        $data->bookkingid = $this->get_new_parentid('bookking');
        $data->starttime = $this->apply_date_offset($data->starttime);
        $data->timemodified = $this->apply_date_offset($data->timemodified);
        $data->emaildate = $this->apply_date_offset($data->emaildate);
        $data->hideuntil = $this->apply_date_offset($data->hideuntil);

        $data->teacherid = $this->get_mappingid('user', $data->teacherid);

        $newitemid = $DB->insert_record('bookking_slots', $data);
        $this->set_mapping('bookking_slot', $oldid, $newitemid, true);
    }

    protected function process_bookking_appointment($data) {
        global $DB;

        $data = (object)$data;
        $oldid = $data->id;

        $data->slotid = $this->get_new_parentid('bookking_slot');

        $data->timecreated = $this->apply_date_offset($data->timecreated);
        $data->timemodified = $this->apply_date_offset($data->timemodified);

        $data->studentid = $this->get_mappingid('user', $data->studentid);

        $newitemid = $DB->insert_record('bookking_appointment', $data);
        $this->set_mapping('bookking_appointment', $oldid, $newitemid, true);
    }

    protected function after_execute() {
        // Add bookking related files.
        $this->add_related_files('mod_bookking', 'intro', null);
        $this->add_related_files('mod_bookking', 'bookinginstructions', null);
        $this->add_related_files('mod_bookking', 'slotnote', 'bookking_slot');
        $this->add_related_files('mod_bookking', 'appointmentnote', 'bookking_appointment');
        $this->add_related_files('mod_bookking', 'teachernote', 'bookking_appointment');
        $this->add_related_files('mod_bookking', 'studentfiles', 'bookking_appointment');
    }
}
